package accadglidassignment;

public class Example {
	int x;
	int y;
	String name;

	public static void main(String args[]) {
		Example pnt = new Example();
		System.out.println("pnt is " + pnt.name + " " + pnt.x + " " + pnt.y);
	}
}
